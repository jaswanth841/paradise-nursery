import React from "react";
import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import ProductList from "./ProductList";
import CartItem from "./CartItem";
import AboutUs from "./AboutUs";
import "./App.css";

function Navbar() {
  const items = useSelector((state) => state.cart.items);
  const count = items.reduce((total, item) => total + item.quantity, 0);
  const location = useLocation();

  return (
    <nav className="navbar">
      <Link className="brand" to="/" aria-label="Paradise Nursery home">
        <span className="brand-icon">✿</span> Paradise Nursery
      </Link>
      <div className="nav-links">
        <Link className={location.pathname === "/" ? "active" : ""} to="/">Home</Link>
        <Link className={location.pathname === "/plants" ? "active" : ""} to="/plants">Plants</Link>
        <Link className={location.pathname === "/cart" ? "active" : ""} to="/cart">
          <span aria-hidden="true">🛒</span> Cart <span className="cart-count">{count}</span>
        </Link>
      </div>
    </nav>
  );
}

function Home() {
  return (
    <main className="home-page">
      <section className="hero">
        <div className="hero-content">
          <p className="eyebrow">A LITTLE MORE GREEN, EVERY DAY</p>
          <h1>Make room for<br /><span>something green.</span></h1>
          <p className="hero-copy">
            Bring home the calm of nature. Find your new favourite plant and
            turn any corner into a happier, greener space.
          </p>
          <Link className="primary-button" to="/plants">Get Started <span aria-hidden="true">→</span></Link>
          <div className="hero-note"><span>✓</span> Thoughtful plants for every space</div>
        </div>
        <div className="hero-badge"><span>GROW</span><strong>good things</strong><span>HERE</span></div>
      </section>
      <div className="home-about"><AboutUs /></div>
      <section className="home-prompt">
        <p className="eyebrow">YOUR GREEN JOURNEY STARTS HERE</p>
        <h2>Find the plant that feels like you.</h2>
        <Link className="secondary-button" to="/plants">Explore our plants</Link>
      </section>
    </main>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/plants" element={<ProductList />} />
        <Route path="/cart" element={<CartItem />} />
        <Route path="*" element={<main className="page-container"><h1>Page not found</h1><Link to="/">Return home</Link></main>} />
      </Routes>
      <footer className="site-footer">© {new Date().getFullYear()} Paradise Nursery <span>Made for greener living.</span></footer>
    </BrowserRouter>
  );
}
