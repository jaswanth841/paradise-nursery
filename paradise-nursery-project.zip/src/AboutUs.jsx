import React from "react";

export default function AboutUs() {
  return (
    <section className="about-section">
      <p className="eyebrow">GROW WITH US</p>
      <h2>About Paradise Nursery</h2>
      <p>
        Paradise Nursery is your destination for beautiful indoor and outdoor
        plants. We help make every home greener with carefully selected plants
        and simple care inspiration.
      </p>
      <h3>Our Mission</h3>
      <p>
        Our mission is to make plant care accessible and bring nature, freshness,
        and happiness into every home.
      </p>
    </section>
  );
}
