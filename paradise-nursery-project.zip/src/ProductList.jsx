import React from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addToCart } from "./CartSlice";

const plants = [
  { id: 1, name: "Snake Plant", price: 299, category: "Indoor Plants", image: "https://images.unsplash.com/photo-1593482892290-f54927ae2b70?auto=format&fit=crop&w=700&q=80", description: "Easy-care, sculptural leaves" },
  { id: 2, name: "Monstera", price: 499, category: "Indoor Plants", image: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=700&q=80", description: "A bold tropical favourite" },
  { id: 3, name: "Peace Lily", price: 349, category: "Indoor Plants", image: "https://images.unsplash.com/photo-1593691509543-c55fb32e5cee?auto=format&fit=crop&w=700&q=80", description: "Soft green leaves" },
  { id: 4, name: "Golden Pothos", price: 199, category: "Indoor Plants", image: "https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=700&q=80", description: "Lovely trailing vines" },
  { id: 5, name: "ZZ Plant", price: 399, category: "Indoor Plants", image: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=700&q=80", description: "Glossy, low-maintenance" },
  { id: 6, name: "Rubber Plant", price: 449, category: "Indoor Plants", image: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=700&q=80", description: "Deep green statement leaves" },
  { id: 7, name: "Rose Plant", price: 249, category: "Outdoor Plants", image: "https://images.unsplash.com/photo-1494972308805-463bc619d34e?auto=format&fit=crop&w=700&q=80", description: "Classic garden colour" },
  { id: 8, name: "Hibiscus", price: 199, category: "Outdoor Plants", image: "https://images.unsplash.com/photo-1597055181300-a8b5be3a5c1b?auto=format&fit=crop&w=700&q=80", description: "Bright tropical blooms" },
  { id: 9, name: "Jasmine", price: 179, category: "Outdoor Plants", image: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=700&q=80", description: "Delicate fragrant flowers" },
  { id: 10, name: "Bougainvillea", price: 299, category: "Outdoor Plants", image: "https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=700&q=80", description: "Colourful climbing beauty" },
  { id: 11, name: "Marigold", price: 99, category: "Outdoor Plants", image: "https://images.unsplash.com/photo-1508610048659-a06b669e3321?auto=format&fit=crop&w=700&q=80", description: "Cheerful sunny flowers" },
  { id: 12, name: "Lavender", price: 279, category: "Outdoor Plants", image: "https://images.unsplash.com/photo-1499002238440-d264edd596ec?auto=format&fit=crop&w=700&q=80", description: "A calming garden favourite" },
  { id: 13, name: "Aloe Vera", price: 149, category: "Succulents", image: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=700&q=80", description: "A hardy, useful succulent" },
  { id: 14, name: "Echeveria", price: 199, category: "Succulents", image: "https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?auto=format&fit=crop&w=700&q=80", description: "Beautiful rosette shape" },
  { id: 15, name: "Jade Plant", price: 229, category: "Succulents", image: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&w=700&q=80", description: "A cheerful desk companion" },
  { id: 16, name: "Haworthia", price: 179, category: "Succulents", image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=700&q=80", description: "Compact and distinctive" },
  { id: 17, name: "String of Pearls", price: 299, category: "Succulents", image: "https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=700&q=80", description: "Trailing bead-like leaves" },
  { id: 18, name: "Mini Cactus", price: 129, category: "Succulents", image: "https://images.unsplash.com/photo-1509937528035-ad76254b0356?auto=format&fit=crop&w=700&q=80", description: "Small plant, big character" }
];

const categories = ["Indoor Plants", "Outdoor Plants", "Succulents"];

export default function ProductList() {
  const dispatch = useDispatch();
  const items = useSelector((state) => state.cart.items);

  return (
    <main className="page-container">
      <div className="section-heading">
        <div><p className="eyebrow">THE PLANT COLLECTION</p><h1>Find your green.</h1></div>
        <Link className="text-link" to="/cart">View your cart →</Link>
      </div>
      <p className="page-subtitle left-subtitle">Thoughtfully picked plants to brighten your everyday.</p>
      {categories.map((category) => (
        <section key={category} className="plant-category">
          <div className="category-heading"><h2>{category}</h2><span>{plants.filter((plant) => plant.category === category).length} plants</span></div>
          <div className="plant-grid">
            {plants.filter((plant) => plant.category === category).map((plant) => {
              const added = items.some((item) => item.id === plant.id);
              return (
                <article className="plant-card" key={plant.id}>
                  <div className="plant-image-wrap">
                    <img src={plant.image} alt={plant.name} className="plant-image" loading="lazy" />
                    <span className="plant-tag">{category === "Indoor Plants" ? "INDOOR" : category === "Outdoor Plants" ? "OUTDOOR" : "SUCCULENT"}</span>
                  </div>
                  <div className="plant-info">
                    <h3>{plant.name}</h3><p className="plant-description">{plant.description}</p>
                    <div className="plant-card-bottom"><span className="price">₹{plant.price.toFixed(2)}</span>
                      <button className="primary-button add-button" disabled={added} onClick={() => dispatch(addToCart(plant))}>
                        {added ? "Added ✓" : "Add to Cart +"}
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      ))}
    </main>
  );
}
