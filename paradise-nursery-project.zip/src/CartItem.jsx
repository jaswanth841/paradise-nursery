import React from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { increaseQuantity, decreaseQuantity, removeFromCart } from "./CartSlice";

export default function CartItem() {
  const dispatch = useDispatch();
  const items = useSelector((state) => state.cart.items);
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <main className="page-container cart-page">
      <p className="eyebrow">YOUR SELECTION</p>
      <h1 className="cart-title">Your shopping cart</h1>
      {items.length === 0 ? (
        <section className="empty-cart">
          <div className="empty-cart-icon">♧</div>
          <h2>Your cart is waiting to grow.</h2>
          <p>You haven't added any plants yet. Find one that feels like you.</p>
          <Link className="primary-button" to="/plants">Continue Shopping →</Link>
        </section>
      ) : (
        <div className="cart-layout">
          <section className="cart-list">
            <div className="cart-list-header"><span>{itemCount} item{itemCount === 1 ? "" : "s"}</span><Link to="/plants">+ Add more plants</Link></div>
            {items.map((item) => (
              <article className="cart-item" key={item.id}>
                <img src={item.image} alt={item.name} className="cart-image" />
                <div className="cart-details">
                  <h3>{item.name}</h3><p className="cart-unit-price">₹{item.price.toFixed(2)} <span>per plant</span></p>
                  <div className="quantity-controls">
                    <button aria-label={`Decrease ${item.name} quantity`} disabled={item.quantity <= 1} onClick={() => dispatch(decreaseQuantity(item.id))}>−</button>
                    <span className="quantity-value">{item.quantity}</span>
                    <button aria-label={`Increase ${item.name} quantity`} onClick={() => dispatch(increaseQuantity(item.id))}>+</button>
                    <button className="delete-button" onClick={() => dispatch(removeFromCart(item.id))}>Remove</button>
                  </div>
                </div>
                <strong className="cart-line-total">₹{(item.price * item.quantity).toFixed(2)}</strong>
              </article>
            ))}
            <Link className="continue-link" to="/plants">← Continue shopping</Link>
          </section>
          <aside className="cart-summary">
            <p className="eyebrow">ORDER SUMMARY</p><h2>Order total</h2>
            <div className="summary-row"><span>Plants ({itemCount} items)</span><span>₹{total.toFixed(2)}</span></div>
            <div className="summary-row"><span>Delivery</span><span className="free-label">Calculated later</span></div>
            <div className="summary-total"><span>Total</span><strong>₹{total.toFixed(2)}</strong></div>
            <button className="primary-button checkout-button" onClick={() => window.alert("Checkout Coming Soon!")}>Proceed to Checkout →</button>
            <p className="checkout-note">Checkout is a demo feature and is not yet available.</p>
          </aside>
        </div>
      )}
    </main>
  );
}
