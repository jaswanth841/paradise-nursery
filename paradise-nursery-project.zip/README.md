# Paradise Nursery

Paradise Nursery is a React-based plant shopping application for browsing indoor plants, outdoor plants, and succulents.

## Features
- Landing page with background image and Get Started button
- About Us section
- Three plant categories with six plants per category
- Plant thumbnails, names, and prices
- Add to Cart button disables after a product is added
- Redux Toolkit cart state
- Dynamic cart item count
- Quantity increase/decrease controls
- Remove products from cart
- Automatic item totals and cart total
- Checkout Coming Soon message
- Continue Shopping link
- Responsive layout

## Technologies
React, Vite, JavaScript, CSS, Redux Toolkit, React Redux, React Router DOM.

## Run locally
1. Install Node.js.
2. Extract or clone this repository.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown in the terminal.

## Project name
Paradise Nursery - Online Plant Shopping Application
